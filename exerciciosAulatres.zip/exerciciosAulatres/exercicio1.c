#include <stdio.h>

int main(void)
{
    int i;
    for (i = 1; i <= 9; i++)
        printf("%d\n", i);
    return 0;
}
